package com.RestDemo.RestDemoExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestDemoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
