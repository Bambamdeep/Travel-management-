package com.mvcSelfProject.SelfProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelfProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
