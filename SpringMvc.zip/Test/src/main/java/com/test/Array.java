package com.test;
import java.util.*;
public class Array {

	public static void main(String[] args) {
		    Scanner sc = new Scanner(System.in);
		 //   int n = sc.nextInt();
//		int arr  [] = new int[n];
//	     
//		for (int i=0; i<n;i++) {
//			arr[i] = sc.nextInt();
//			System.out.println("");
//			System.out.println(arr[i]);
//		}
		int count = 0;
		String [] str = {"HI","Deepak","Kumar"};
		String s = Arrays.toString(str);
		System.out.println(str);
		int st = str.length;
		System.out.println(s);
		System.out.println(st);
		//String[] str1 = str.split(" \\s ");
		//String s = Arrays.toString(str1); 
		
		//char charray[]=  {'p','r','a'};
		
		//String chToString=charray.toString();
		//String s = str1.toString();
		
//		char[] c = str.toCharArray();
//		 int a = c.length;
//		for(int i =0;i<a;i++) {
//			 if (c[i]=='e' ) {
//				 count++;
//			 }
//		}
//		System.out.println(count);
		//System.out.println(str1);
		//System.out.println(chToString);
	}

}
