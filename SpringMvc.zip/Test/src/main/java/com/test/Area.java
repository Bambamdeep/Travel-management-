package com.test;

public abstract class Area {
   public abstract int area();
   static int a =10;
   void display() {
		System.out.println("drived class + " + a);
	}
}
