package com.One2ManySir.One2ManySir;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class One2ManySirApplication implements CommandLineRunner{
@Autowired
PostDao postDao;
@Autowired
CommentsDao commentsDao;

	public static void main(String[] args) {
		SpringApplication.run(One2ManySirApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Comment comment1 = new Comment(9001L,"Good");
		Comment comment2 = new Comment(9002L,"average");
		Comment comment3 = new Comment(9003L,"good");
		List<Comment> comments = new ArrayList<Comment>();
		comments.add(comment3);
		comments.add(comment2);
		comments.add(comment1);
		
		Post post = new Post(1001L,"First Post",comments);
		
		postDao.save(post);
		
		
		 System.out.println("one2many mapping done..123");
	     System.out.println	(postDao.findById(9001L));
//		//fetching the data
	 postDao.findAll().forEach(System.out::println);
	//fetching the data
//	Iterable<Post> cmts = postDao.findAll();
//			cmts.forEach(System.out::println);
			
		
		
	}

}
