package com.MicroServiceProject.MicroServiceApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
