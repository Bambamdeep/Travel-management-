package com.ProjectExample.ProjectExample;

import java.util.List;

public interface StudentService {
public List<Student> getAll();
public Student insert(Student student);

}
