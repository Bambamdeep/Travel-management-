package com.ProjectExample.ProjectExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
