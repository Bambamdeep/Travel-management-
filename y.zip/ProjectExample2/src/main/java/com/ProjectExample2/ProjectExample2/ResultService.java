package com.ProjectExample2.ProjectExample2;

import java.util.List;

public interface ResultService {
public List<Result> getResultAll();
public Result insertResult(Result result);
public Result getResult (int roll);
}
