package com.ProjectExample2.ProjectExample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectExample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
