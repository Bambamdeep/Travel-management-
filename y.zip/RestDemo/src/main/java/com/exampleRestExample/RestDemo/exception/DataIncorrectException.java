package com.exampleRestExample.RestDemo.exception;

public class DataIncorrectException extends RuntimeException {
public  DataIncorrectException() {
	super("Data is Incorrect");
}
}
