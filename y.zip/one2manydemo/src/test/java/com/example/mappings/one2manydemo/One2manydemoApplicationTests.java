package com.example.mappings.one2manydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class One2manydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
