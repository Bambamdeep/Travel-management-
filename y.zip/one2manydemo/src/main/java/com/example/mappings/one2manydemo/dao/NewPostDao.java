package com.example.mappings.one2manydemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mappings.one2manydemo.model.NewPost;
import com.example.mappings.one2manydemo.model.Post;

public interface NewPostDao extends JpaRepository<NewPost,Long>{

	void save(Post post);

}
