package com.One2Many.One2Many;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Author {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String author_Name;
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Author(int id, String author_Name) {
		super();
		this.id = id;
		this.author_Name = author_Name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAuthor_Name() {
		return author_Name;
	}
	public void setAuthor_Name(String author_Name) {
		this.author_Name = author_Name;
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", author_Name=" + author_Name + "]";
	}

}
