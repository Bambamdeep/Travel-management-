package com.One2Many.One2Many;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String book_Name;
 @OneToMany(cascade = CascadeType.ALL)
 @JoinColumn(name = "BOOK_Details")
    private List<Author> author = new ArrayList<>();
public Book() {
	super();
	// TODO Auto-generated constructor stub
}
public Book(int id, String book_Name, List<Author> author) {
	super();
	this.id = id;
	this.book_Name = book_Name;
	this.author = author;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBook_Name() {
	return book_Name;
}
public void setBook_Name(String book_Name) {
	this.book_Name = book_Name;
}
public List<Author> getAuthor() {
	return author;
}
public void setAuthor(List<Author> author) {
	this.author = author;
}
@Override
public String toString() {
	return "Book [id=" + id + ", book_Name=" + book_Name + ", author=" + author + "]";
}
 
}
