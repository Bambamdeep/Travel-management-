package com.One2Many.One2Many;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class One2ManyApplication implements CommandLineRunner{
@Autowired
AuthorDao authorDao;
@Autowired
BookDao bookDao;
	public static void main(String[] args) {
		SpringApplication.run(One2ManyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Author A = new Author(1, "chetan Bagath");
		Author A1 = new Author(2,"Vikram Seth");
		Author A2 = new Author(3,"RK Narayan");
		Author A3 = new Author(4,"Ruskin Bond");
		List<Author> authors = new ArrayList<>();
		authors.add(A);
		authors.add(A1);
		authors.add(A2);
		authors.add(A3);
		
		Book book = new Book(6,"ikagai",authors);
		bookDao.save(book);
		System.out.println("One2Many");
	System.out.println(bookDao.findById(3));
		
	}

}
