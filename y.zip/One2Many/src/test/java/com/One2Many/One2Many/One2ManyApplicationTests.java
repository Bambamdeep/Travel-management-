package com.One2Many.One2Many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class One2ManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
