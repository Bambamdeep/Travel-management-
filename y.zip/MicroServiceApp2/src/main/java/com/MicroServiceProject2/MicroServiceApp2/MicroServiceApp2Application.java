package com.MicroServiceProject2.MicroServiceApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiceApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceApp2Application.class, args);
	}

}
