package com.MicroServiceProject2.MicroServiceApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
