package com.OpenFeign1.MicroServiceFegin1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceFegin1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
