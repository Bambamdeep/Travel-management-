package com.OpenFeign.MicroServiceFegin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceFeginApplicationTests {

	@Test
	void contextLoads() {
	}

}
