package com.One2One.One2One;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class One2OneApplication implements CommandLineRunner{
@Autowired
TuserDao tuserDao;
@Autowired
TuserProfileDao tuserprofileDao;
@Autowired
PersonDao personDao;
@Autowired
PassportDao passportDao;
	public static void main(String[] args) {
		SpringApplication.run(One2OneApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub	System.out.println("This Is DeepakKumar");
	 //This One2One UniDirectional;
	
		TuserProfile T = new TuserProfile(1,"Deepak");
		TuserProfile T1 = new TuserProfile(2,"Ishu");
		TuserProfile T2 = new TuserProfile(3,"Aditi");
		TuserProfile T3 = new TuserProfile(4,"Deepa");
		TuserProfile T4 = new TuserProfile(5,"Narendra");
		TuserProfile T5 = new TuserProfile(6,"Bhardwaj");
		TuserProfile T6 = new TuserProfile(7,"Rita");
		TuserProfile T7 = new TuserProfile(8,"Nandani");
		Tuser t = new Tuser(12,"xyz@gmail.com",T);
		Tuser t1 = new Tuser(13,"abc@gmail.com",T1);
		Tuser t2 = new Tuser(14,"ABC@gmail.com",T2);
		Tuser t3 = new Tuser(15,"XYZ@gmail.com",T3);
		Tuser t4 = new Tuser(16,"13@gmail.com",T4);
		Tuser t5 = new Tuser(17,"12@gmail.com",T5);
		Tuser t6 = new Tuser(18,"15@gmail.com",T6);
		Tuser t7 = new Tuser(119,"16@gmail.com",T7);
		tuserDao.save(t);
		tuserDao.save(t1);
		tuserDao.save(t2);
		tuserDao.save(t3);
		tuserDao.save(t4);
		tuserDao.save(t5);
		tuserDao.save(t6);
		tuserDao.save(t7);
		System.out.println("Successfully Mapped");
		tuserDao.findAll().forEach(System.out::println);
		tuserDao.deleteById(12);
		tuserDao.deleteById(4);
		System.out.println(tuserDao.findById(4));
//		
		tuserDao.findAll().forEach(System.out::println);
//		
	Passport passport = new Passport();
	passport.setAddress("Patna");
	//passport.setId(20);
//	
//	Passport passport1 = new Passport();
//	passport.setAddress("Bihar");
//	passport.setId(10);
		
		Person person = new Person();
		person.setId(15);
		person.setName("DEEPAK");
//		
//		Person person1 = new Person();
//		person.setId(5);
//		person.setName("Bambam");
//		person.setPassport(passport1);
//		passport.setPerson(person1);
		
		personDao.save(person);
		passportDao.save(passport);
		
//		personDao.save(person1);
//		passportDao.save(passport1);
		
		System.out.println("One2One bidirectional");
	System.out.println(personDao.findById(20));
	personDao.findAll().forEach(System.out::println);
		
       
	}

}
