package com.One2One.One2One;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Passport {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String address;
	@OneToOne(mappedBy = "passport")
        private	 Person person;
	public Passport() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Passport(int id, String address, Person person) {
		super();
		this.id = id;
		this.address = address;
		this.person = person;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	@Override
	public String toString() {
		return "Passport [id=" + id + ", address=" + address + ", person=" + person + "]";
	}
	
}
