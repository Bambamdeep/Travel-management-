package com.One2One.One2One;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Person {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
int id;
String name;
@OneToOne(cascade =CascadeType.ALL)
@JoinColumn(name= "PASSPORT_Details", referencedColumnName = "id")
private Passport passport;
public Person() {
	super();
	// TODO Auto-generated constructor stub
}
public Person(int id, String name, Passport passport) {
	super();
	this.id = id;
	this.name = name;
	this.passport = passport;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Passport getPassport() {
	return passport;
}
public void setPassport(Passport passport) {
	this.passport = passport;
}
@Override
public String toString() {
	return "Person [id=" + id + ", name=" + name + ", passport=" + passport + "]";
}


}
