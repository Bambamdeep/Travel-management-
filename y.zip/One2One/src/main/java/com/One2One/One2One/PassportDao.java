package com.One2One.One2One;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PassportDao extends JpaRepository<Passport,Integer>{

}
