package com.One2One.One2One;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Tuser")
public class Tuser {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String email;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Profile_Id",referencedColumnName = "id")
	private TuserProfile tuserprofile;
	public Tuser() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Tuser(int id, String email, TuserProfile tuserprofile) {
		super();
		this.id = id;
		this.email = email;
		this.tuserprofile = tuserprofile;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public TuserProfile getTuserprofile() {
		return tuserprofile;
	}
	public void setTuserprofile(TuserProfile tuserprofile) {
		this.tuserprofile = tuserprofile;
	}
	@Override
	public String toString() {
		return "Tuser [id=" + id + ", email=" + email + ", tuserprofile=" + tuserprofile + "]";
	}
	
	

}
