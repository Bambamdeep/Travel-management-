package com.One2One.One2One;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class One2OneApplicationTests {

	@Test
	void contextLoads() {
	}

}
