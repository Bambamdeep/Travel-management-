package com.HealthCareProvider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
