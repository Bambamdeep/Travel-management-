package com.example.handson4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Handson4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
