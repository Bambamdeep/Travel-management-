package com.exampleJunitExample.JunitExample;

   public class Mathmematics {
               public int add(int a, int b) {
	                       return a+b;
               }
               
               
                        public int divide(int x, int y) {
	                     return x / y;
                         }
}
