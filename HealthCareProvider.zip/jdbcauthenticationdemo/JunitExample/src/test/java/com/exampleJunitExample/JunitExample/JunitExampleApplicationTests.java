package com.exampleJunitExample.JunitExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
