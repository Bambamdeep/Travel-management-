package com.exampleJunitExample.JunitExample;

public class JunitDemo {

}
