package com.jdbcauthenticationdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcauthenticationdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcauthenticationdemoApplication.class, args);
	}

}
