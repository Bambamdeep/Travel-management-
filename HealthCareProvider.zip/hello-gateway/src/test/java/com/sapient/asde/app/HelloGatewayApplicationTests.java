package com.sapient.asde.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
