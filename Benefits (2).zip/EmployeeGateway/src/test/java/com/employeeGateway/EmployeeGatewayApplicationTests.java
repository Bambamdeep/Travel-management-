package com.employeeGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
