package com.Benefit.Benefits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenefitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
