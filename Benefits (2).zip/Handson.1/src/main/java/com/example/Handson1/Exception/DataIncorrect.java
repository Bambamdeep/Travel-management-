package com.example.Handson1.Exception;

public class DataIncorrect extends RuntimeException{
	public DataIncorrect() {
		super("Enter Data Is Incorrect");
	}

}
