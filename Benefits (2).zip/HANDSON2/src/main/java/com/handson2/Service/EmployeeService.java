package com.handson2.Service;

import java.util.List;

import com.handson2.Model.Employee;

public interface EmployeeService {
public Employee addEmp(Employee employee);
public List<Employee> getAllEmp();
}
