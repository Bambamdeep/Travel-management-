package com.handson2.HANDSON2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Handson2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
