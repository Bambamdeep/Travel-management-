package com.example.handson4.Exception;

public class IdNotFoundException extends RuntimeException{
public IdNotFoundException() {
	super("Student Not Found");
}
}
