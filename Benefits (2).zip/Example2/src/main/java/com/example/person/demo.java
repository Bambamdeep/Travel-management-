package com.example.person;

public interface demo {

}
