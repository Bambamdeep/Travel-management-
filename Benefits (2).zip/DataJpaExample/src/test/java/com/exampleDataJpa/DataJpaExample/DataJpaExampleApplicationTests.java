package com.exampleDataJpa.DataJpaExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
