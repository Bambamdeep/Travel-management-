package com.exception;

public class practice extends RuntimeException {
 String message;
	public practice(String message) {
		this.message = message;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
