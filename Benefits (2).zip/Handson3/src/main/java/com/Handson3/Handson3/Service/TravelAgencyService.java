package com.Handson3.Handson3.Service;

import java.util.List;

import com.Handson3.Handson3.Model.TravelAgency;

public interface TravelAgencyService {
     //add
	public TravelAgency create(TravelAgency agency);
	// get 
	//public List<TravelAgency>   getAll();
	
	
	
	
	
	
	
	
}
