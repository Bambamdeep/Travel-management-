package com.Handson3.Handson3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Handson3ApplicationTests {
 @Test
	public void test() {
		
	}
}
