package exampl;

public interface Shape {
public int getarea ();
}
