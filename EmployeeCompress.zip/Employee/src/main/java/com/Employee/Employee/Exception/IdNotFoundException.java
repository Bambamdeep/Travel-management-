package com.Employee.Employee.Exception;

public class IdNotFoundException extends RuntimeException{
	public IdNotFoundException() {
super ("Entered empId is Wrong");
}
}